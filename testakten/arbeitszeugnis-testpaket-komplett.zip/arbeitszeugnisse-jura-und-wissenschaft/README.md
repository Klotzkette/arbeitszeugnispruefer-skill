# Testakte: Arbeitszeugnisse — Jura und Wissenschaft

Diese zweite Testakte begleitet den Skill [`arbeitszeugnispruefer`](../../skill/SKILL.md) als juristisch-akademisches Trainingsmaterial. Sie enthält zehn fiktive Arbeitszeugnisse: fünf aus dem akademischen Bereich juristischer Lehrstühle und fünf aus Kanzlei- beziehungsweise juristischen Praxisrollen. Alle Personen, Universitäten, Kanzleien, Adressen und Kommunikationsdaten sind frei erfunden.

**Navigation:** [Hauptübersicht](../../README.md) · [Testakten-Zentrale](../README.md) · [Fallmatrix 01–25](../TESTFALL-MATRIX.md) · [alle Release-Dateien](https://github.com/Klotzkette/arbeitszeugnispruefer-skill/releases/latest) · [Prüfsummen](https://github.com/Klotzkette/arbeitszeugnispruefer-skill/releases/latest/download/SHA256SUMS.txt) · [Allgemeine Branchen](../arbeitszeugnis-analyse-bluehendes-leben/README.md) · **Jura und Wissenschaft** · [Leitungsfunktionen](../arbeitszeugnisse-leitungsfunktionen/README.md)

## Schnellzugriff

| Ziel | Link |
| --- | --- |
| Zur Hauptübersicht | [`README.md`](../../README.md) |
| Öffentliche Downloadseite | [GitHub Pages](https://klotzkette.github.io/arbeitszeugnispruefer-skill/) |
| Voll- und Mini-Skill | [Vollversion herunterladen](https://github.com/Klotzkette/arbeitszeugnispruefer-skill/releases/latest/download/SKILL.md) · [Mini-Version herunterladen](https://github.com/Klotzkette/arbeitszeugnispruefer-skill/releases/latest/download/SKILL-mini.md) |
| Vollständiges Release und Prüfsummen | [alle zehn Release-Dateien](https://github.com/Klotzkette/arbeitszeugnispruefer-skill/releases/latest) · [`SHA256SUMS.txt` herunterladen](https://github.com/Klotzkette/arbeitszeugnispruefer-skill/releases/latest/download/SHA256SUMS.txt) |
| Alle 25 Fälle und Ground Truth | [Komplettpaket herunterladen](https://github.com/Klotzkette/arbeitszeugnispruefer-skill/releases/latest/download/arbeitszeugnis-testpaket-komplett.zip) · [Fallmatrix](../TESTFALL-MATRIX.md) |
| ZIP mit allen 10 Einzel-PDFs | [direkt herunterladen](https://github.com/Klotzkette/arbeitszeugnispruefer-skill/releases/latest/download/arbeitszeugnisse-jura-und-wissenschaft-einzel-pdfs.zip) · [`Repository-Datei`](arbeitszeugnisse-jura-und-wissenschaft-einzel-pdfs.zip) |
| Gesamt-PDF aller 10 Zeugnisse | [direkt herunterladen](https://github.com/Klotzkette/arbeitszeugnispruefer-skill/releases/latest/download/arbeitszeugnisse-jura-und-wissenschaft_gesamt.pdf) · [`Repository-Datei`](gesamt-pdf/arbeitszeugnisse-jura-und-wissenschaft_gesamt.pdf) |
| Erwartungshorizont und Prüfpunkte | [`90-erwartungshorizont-und-pruefpunkte.md`](90-erwartungshorizont-und-pruefpunkte.md) |

## Zweck der Akte

Die Zeugnisse trainieren Rollen, die im klassischen Zeugnisfundus oft fehlen: wissenschaftliche Mitarbeit an juristischen Lehrstühlen, Postdoc-/Drittmittelkontexte, Probezeit in der Großkanzlei, Kanzleileitung ohne Anwaltszulassung, ReNo-/Fristenarbeit und Senior-Associate-Bewertungen in kleinen und großen Kanzleien.

Die Briefköpfe sind absichtlich ausführlicher gestaltet als in einfachen Musterzeugnissen. Personalzeichen, Projektbezug, Registerangaben, HR-/Ausstellerrolle, Dienstsiegel oder Kanzleistempel sollen mitgeprüft werden: Sie helfen, Zeugnisart, Ausstellerkompetenz, Rollenabgrenzung und formale Plausibilität zu erkennen.

Die Bewertungen sind absichtlich gemischt. Einige Zeugnisse sind sehr gut, andere enthalten typische Drift-, Auslassungs-, Rollen- oder Schlussformelprobleme. Der Skill soll nicht nur Codewörter suchen, sondern Rolle, Zeugnisart, Aufgabenprofil, Beendigungsgrund und Erwartungshorizont zusammenführen.

## Aktenübersicht

| Nr. | Person | Rolle | Umfeld | Typ / Anlass | Einzel-PDF |
| --- | --- | --- | --- | --- | --- |
| 11 | Johanna Kirchhoff | Wissenschaftliche Mitarbeiterin am juristischen Lehrstuhl | Universität / Zivilrecht | Endzeugnis, Promotionsabschluss und Wechsel ins Referendariat | [ansehen](11-johanna-kirchhoff-wissmit-zivilrecht/Arbeitszeugnis_11-johanna-kirchhoff-wissmit-zivilrecht.pdf) · [herunterladen](https://github.com/Klotzkette/arbeitszeugnispruefer-skill/raw/refs/heads/main/testakten/arbeitszeugnisse-jura-und-wissenschaft/11-johanna-kirchhoff-wissmit-zivilrecht/Arbeitszeugnis_11-johanna-kirchhoff-wissmit-zivilrecht.pdf) |
| 12 | Tobias Rauch | Wissenschaftlicher Mitarbeiter am Lehrstuhl für Strafrecht | Universität / Strafrecht | Endzeugnis, Auslaufen der Projektbefristung | [ansehen](12-tobias-rauch-wissmit-strafrecht/Arbeitszeugnis_12-tobias-rauch-wissmit-strafrecht.pdf) · [herunterladen](https://github.com/Klotzkette/arbeitszeugnispruefer-skill/raw/refs/heads/main/testakten/arbeitszeugnisse-jura-und-wissenschaft/12-tobias-rauch-wissmit-strafrecht/Arbeitszeugnis_12-tobias-rauch-wissmit-strafrecht.pdf) |
| 13 | Dr. Eline Oster | Postdoktorale wissenschaftliche Mitarbeiterin | Universität / Öffentliches Recht | Zwischenzeugnis, Drittmittelantrag und Lehrstuhlwechsel | [ansehen](13-dr-eline-oster-wissmit-oeffentliches-recht/Arbeitszeugnis_13-dr-eline-oster-wissmit-oeffentliches-recht.pdf) · [herunterladen](https://github.com/Klotzkette/arbeitszeugnispruefer-skill/raw/refs/heads/main/testakten/arbeitszeugnisse-jura-und-wissenschaft/13-dr-eline-oster-wissmit-oeffentliches-recht/Arbeitszeugnis_13-dr-eline-oster-wissmit-oeffentliches-recht.pdf) |
| 14 | Salim Borchert | Wissenschaftlicher Mitarbeiter Legal Tech / Zivilprozess | Universität / Legal Tech | Endzeugnis, Wechsel in die Justiz | [ansehen](14-salim-borchert-wissmit-legal-tech/Arbeitszeugnis_14-salim-borchert-wissmit-legal-tech.pdf) · [herunterladen](https://github.com/Klotzkette/arbeitszeugnispruefer-skill/raw/refs/heads/main/testakten/arbeitszeugnisse-jura-und-wissenschaft/14-salim-borchert-wissmit-legal-tech/Arbeitszeugnis_14-salim-borchert-wissmit-legal-tech.pdf) |
| 15 | Antonia Weber | Wissenschaftliche Mitarbeiterin mit Lehrstuhlorganisation | Universität / Arbeitsrecht | Endzeugnis, Beendigung nach Befristungsablauf | [ansehen](15-antonia-weber-wissmit-lehrstuhlorganisation/Arbeitszeugnis_15-antonia-weber-wissmit-lehrstuhlorganisation.pdf) · [herunterladen](https://github.com/Klotzkette/arbeitszeugnispruefer-skill/raw/refs/heads/main/testakten/arbeitszeugnisse-jura-und-wissenschaft/15-antonia-weber-wissmit-lehrstuhlorganisation/Arbeitszeugnis_15-antonia-weber-wissmit-lehrstuhlorganisation.pdf) |
| 16 | Markus Lentner | Fremdgeschäftsführer / Kanzleileiter ohne Anwaltszulassung | Große Wirtschaftskanzlei | Endzeugnis, Aufhebungsvereinbarung | [ansehen](16-markus-lentner-kanzleigeschaeftsfuehrer/Arbeitszeugnis_16-markus-lentner-kanzleigeschaeftsfuehrer.pdf) · [herunterladen](https://github.com/Klotzkette/arbeitszeugnispruefer-skill/raw/refs/heads/main/testakten/arbeitszeugnisse-jura-und-wissenschaft/16-markus-lentner-kanzleigeschaeftsfuehrer/Arbeitszeugnis_16-markus-lentner-kanzleigeschaeftsfuehrer.pdf) |
| 17 | Lena Hartmann | Junior Associate | Internationale Kanzlei / M&A | Endzeugnis, Beendigung während der Probezeit | [ansehen](17-lena-hartmann-junior-associate-probezeit/Arbeitszeugnis_17-lena-hartmann-junior-associate-probezeit.pdf) · [herunterladen](https://github.com/Klotzkette/arbeitszeugnispruefer-skill/raw/refs/heads/main/testakten/arbeitszeugnisse-jura-und-wissenschaft/17-lena-hartmann-junior-associate-probezeit/Arbeitszeugnis_17-lena-hartmann-junior-associate-probezeit.pdf) |
| 18 | Claudia Renner | Rechtsanwaltsfachangestellte / ReNo-Fachkraft | Kleine Kanzlei | Endzeugnis, Eigenkündigung | [ansehen](18-claudia-renner-reno-fachangestellte/Arbeitszeugnis_18-claudia-renner-reno-fachangestellte.pdf) · [herunterladen](https://github.com/Klotzkette/arbeitszeugnispruefer-skill/raw/refs/heads/main/testakten/arbeitszeugnisse-jura-und-wissenschaft/18-claudia-renner-reno-fachangestellte/Arbeitszeugnis_18-claudia-renner-reno-fachangestellte.pdf) |
| 19 | Jonas Kemper | Senior Associate | Arbeitsrechtsboutique | Zwischenzeugnis, Partnerperspektive / interner Wechsel | [ansehen](19-jonas-kemper-senior-associate-boutique/Arbeitszeugnis_19-jonas-kemper-senior-associate-boutique.pdf) · [herunterladen](https://github.com/Klotzkette/arbeitszeugnispruefer-skill/raw/refs/heads/main/testakten/arbeitszeugnisse-jura-und-wissenschaft/19-jonas-kemper-senior-associate-boutique/Arbeitszeugnis_19-jonas-kemper-senior-associate-boutique.pdf) |
| 20 | Dr. Mira Voss | Senior Associate | Internationale Großkanzlei / Dispute Resolution | Endzeugnis, Wechsel in ein Unternehmen | [ansehen](20-dr-mira-voss-senior-associate-grosskanzlei/Arbeitszeugnis_20-dr-mira-voss-senior-associate-grosskanzlei.pdf) · [herunterladen](https://github.com/Klotzkette/arbeitszeugnispruefer-skill/raw/refs/heads/main/testakten/arbeitszeugnisse-jura-und-wissenschaft/20-dr-mira-voss-senior-associate-grosskanzlei/Arbeitszeugnis_20-dr-mira-voss-senior-associate-grosskanzlei.pdf) |

## Prüfprofil

| Bereich | Worauf der Skill achten soll |
| --- | --- |
| Akademische Rollen | Lehrstuhlorganisation, Drittmittel, Veröffentlichungen, Lehre, Forschung und Projektbefristung nicht schematisch behandeln. |
| Kanzleirollen | Akquisenähe, Mandatsarbeit, Fristen, beA/RVG, Teamarbeit, Associate-Entwicklung und Kanzleileitung sauber trennen. |
| Form und Aussteller | Briefkopf, Personalzeichen, Dienstsiegel, Kanzleistempel, HR-/Ausstellerrolle und Registerangaben mitprüfen. |
| Bewertung | Gemischte Noten, Drift, Auslassungen, Schlussformeln, Probezeit- und Befristungssignale rollenbewusst würdigen. |

## Mögliche Arbeitsaufträge an den Skill

- Einzelnes PDF mit Ampel-Bilanz, Notenspanne und Ersatzformulierungen prüfen.
- Alle zehn Zeugnisse als Batch auswerten und die stärksten roten/orangen Befunde priorisieren.
- Bei Arbeitnehmerperspektive Mandantenbericht und Berichtigungsverlangen erstellen.
- Bei HR-/Arbeitgeberperspektive neutralen Korrekturvermerk mit sicheren Alternativen erstellen.

[Zur vorherigen Testakte: Allgemeine Branchen](../arbeitszeugnis-analyse-bluehendes-leben/README.md) · [Zur Hauptübersicht](../../README.md) · [Zur nächsten Testakte: Leitungsfunktionen](../arbeitszeugnisse-leitungsfunktionen/README.md)
